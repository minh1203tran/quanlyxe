/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.quanlycuahangxe.dao;

import com.quanlycuahangxe.model.Customer;
import com.quanlycuahangxe.exception.CustomerNotFoundException;
import com.quanlycuahangxe.exception.DuplicateCustomerException;
import com.quanlycuahangxe.db.NewConnectPostgres;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Minh
 */
public class CustomerManagementDao {
    private final Connection conn;

    public CustomerManagementDao() {
        this.conn = NewConnectPostgres.getConnection();
    }

    public Customer createCustomer(Customer customer) throws DuplicateCustomerException {
        try {
            if (existsByEmail(customer.getEmail())) {
                throw DuplicateCustomerException.duplicateEmail(customer.getEmail());
            }
            if (existsByPhoneNumber(customer.getPhoneNumber())) {
                throw DuplicateCustomerException.duplicatePhoneNumber(customer.getPhoneNumber());
            }
            String sql = "INSERT INTO customers (first_name,last_name,email,phone_number,address,date_of_birth,gender,is_active,notes,created_at,updated_at) " +
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?) RETURNING id";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, customer.getFirstName());
                ps.setString(2, customer.getLastName());
                ps.setString(3, customer.getEmail());
                ps.setString(4, customer.getPhoneNumber());
                ps.setString(5, customer.getAddress());
                if (customer.getDateOfBirth() != null) {
                    ps.setDate(6, Date.valueOf(customer.getDateOfBirth()));
                } else {
                    ps.setNull(6, Types.DATE);
                }
                ps.setString(7, customer.getGender() != null ? customer.getGender().name() : null);
                ps.setBoolean(8, customer.isActive());
                ps.setString(9, customer.getNotes());
                ps.setTimestamp(10, Timestamp.valueOf(customer.getCreatedAt()));
                ps.setTimestamp(11, Timestamp.valueOf(customer.getUpdatedAt()));
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        customer.setId(rs.getLong("id"));
                    }
                }
            }
            return customer;
        } catch (SQLException e) {
            throw new RuntimeException("Lỗi khi thêm khách hàng: " + e.getMessage(), e);
        }
    }

    public Customer getCustomerById(Long id) throws CustomerNotFoundException {
        try {
            String sql = "SELECT * FROM customers WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Customer c = map(rs);
                rs.close(); ps.close();
                return c;
            } else {
                throw CustomerNotFoundException.withId(id);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Lỗi khi lấy khách hàng: " + e.getMessage(), e);
        }
    }

    public Customer updateCustomer(Long id, Customer customer) throws CustomerNotFoundException {
        if (!existsById(id)) {
            throw CustomerNotFoundException.withId(id);
        }
        try {
            String sql = "UPDATE customers SET first_name=?,last_name=?,email=?,phone_number=?,address=?,date_of_birth=?,gender=?,is_active=?,notes=?,updated_at=? WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, customer.getFirstName());
                ps.setString(2, customer.getLastName());
                ps.setString(3, customer.getEmail());
                ps.setString(4, customer.getPhoneNumber());
                ps.setString(5, customer.getAddress());
                if (customer.getDateOfBirth() != null) {
                    ps.setDate(6, Date.valueOf(customer.getDateOfBirth()));
                } else {
                    ps.setNull(6, Types.DATE);
                }
                ps.setString(7, customer.getGender() != null ? customer.getGender().name() : null);
                ps.setBoolean(8, customer.isActive());
                ps.setString(9, customer.getNotes());
                ps.setTimestamp(10, Timestamp.valueOf(customer.getUpdatedAt()));
                ps.setLong(11, id);
                ps.executeUpdate();
            }
            return getCustomerById(id);
        } catch (SQLException e) {
            throw new RuntimeException("Lỗi khi cập nhật khách hàng: " + e.getMessage(), e);
        }
    }

    public void deleteCustomer(Long id) throws CustomerNotFoundException {
        if (!existsById(id)) {
            throw CustomerNotFoundException.withId(id);
        }
        try {
            String sql = "DELETE FROM customers WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Lỗi khi xóa khách hàng: " + e.getMessage(), e);
        }
    }

    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers ORDER BY created_at DESC";
            try (Statement st = conn.createStatement()) {
                ResultSet rs;
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    list.add(map(rs));
                }
                rs.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> getCustomersWithPaging(int page, int size) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers ORDER BY created_at DESC LIMIT ? OFFSET ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, size);
                ps.setInt(2, (page - 1) * size);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> searchByKeyword(String keyword) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE LOWER(first_name) LIKE ? OR LOWER(last_name) LIKE ? OR LOWER(email) LIKE ? OR phone_number LIKE ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                String kw = "%" + keyword.toLowerCase() + "%";
                ps.setString(1, kw);
                ps.setString(2, kw);
                ps.setString(3, kw);
                ps.setString(4, kw);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public boolean existsById(Long id) {
        try {
            boolean exists;
            try (PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM customers WHERE id=?")) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    exists = rs.next();
                }
            }
            return exists;
        } catch (SQLException e) { return false; }
    }

    public boolean existsByEmail(String email) {
        try {
            boolean exists;
            try (PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM customers WHERE email=?")) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    exists = rs.next();
                }
            }
            return exists;
        } catch (SQLException e) { return false; }
    }

    public boolean existsByPhoneNumber(String phone) {
        try {
            boolean exists;
            try (PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM customers WHERE phone_number=?")) {
                ps.setString(1, phone);
                try (ResultSet rs = ps.executeQuery()) {
                    exists = rs.next();
                }
            }
            return exists;
        } catch (SQLException e) { return false; }
    }

    public boolean existsByEmailAndNotCustomerId(String email, Long excludeId) {
        try {
            boolean exists;
            try (PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM customers WHERE email=? AND id<>?")) {
                ps.setString(1, email);
                ps.setLong(2, excludeId);
                try (ResultSet rs = ps.executeQuery()) {
                    exists = rs.next();
                }
            }
            return exists;
        } catch (SQLException e) { return false; }
    }

    public boolean existsByPhoneNumberAndNotCustomerId(String phone, Long excludeId) {
        try {
            boolean exists;
            try (PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM customers WHERE phone_number=? AND id<>?")) {
                ps.setString(1, phone);
                ps.setLong(2, excludeId);
                try (ResultSet rs = ps.executeQuery()) {
                    exists = rs.next();
                }
            }
            return exists;
        } catch (SQLException e) { return false; }
    }

    public long countCustomers() {
        try {
            long c;
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM customers")) {
                rs.next();
                c = rs.getLong(1);
            }
            return c;
        } catch (SQLException e) { return 0; }
    }

    public long countActiveCustomers() {
        try {
            long c;
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM customers WHERE is_active=true")) {
                rs.next();
                c = rs.getLong(1);
            }
            return c;
        } catch (SQLException e) { return 0; }
    }

    public long countInactiveCustomers() {
        try {
            long c;
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM customers WHERE is_active=false")) {
                rs.next();
                c = rs.getLong(1);
            }
            return c;
        } catch (SQLException e) { return 0; }
    }

    private Customer map(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setId(rs.getLong("id"));
        c.setFirstName(rs.getString("first_name"));
        c.setLastName(rs.getString("last_name"));
        c.setEmail(rs.getString("email"));
        c.setPhoneNumber(rs.getString("phone_number"));
        c.setAddress(rs.getString("address"));
        Date dob = rs.getDate("date_of_birth");
        if (dob != null) c.setDateOfBirth(dob.toLocalDate());
        String gender = rs.getString("gender");
        if (gender != null) c.setGender(Customer.Gender.valueOf(gender));
        c.setActive(rs.getBoolean("is_active"));
        Timestamp created = rs.getTimestamp("created_at");
        if (created != null) c.setCreatedAt(created.toLocalDateTime());
        Timestamp updated = rs.getTimestamp("updated_at");
        if (updated != null) c.setUpdatedAt(updated.toLocalDateTime());
        c.setNotes(rs.getString("notes"));
        return c;
    }

    public List<Customer> findByFirstNameAndLastName(String firstName, String lastName) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE LOWER(first_name)=LOWER(?) AND LOWER(last_name)=LOWER(?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, firstName);
                ps.setString(2, lastName);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> findByFirstName(String firstName) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE LOWER(first_name) LIKE ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, "%" + firstName.toLowerCase() + "%");
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> findByLastName(String lastName) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE LOWER(last_name) LIKE ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, "%" + lastName.toLowerCase() + "%");
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> findByDateOfBirthBetween(java.time.LocalDate start, java.time.LocalDate end) {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE date_of_birth BETWEEN ? AND ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setDate(1, java.sql.Date.valueOf(start));
                ps.setDate(2, java.sql.Date.valueOf(end));
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(map(rs));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public Optional<Customer> findById(Long id) {
        try {
            String sql = "SELECT * FROM customers WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Customer c = map(rs);
                        rs.close(); ps.close();
                        return Optional.of(c);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    public Optional<Customer> findByEmail(String email) {
        try {
            String sql = "SELECT * FROM customers WHERE email=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Customer c = map(rs);
                        rs.close(); ps.close();
                        return Optional.of(c);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    public Optional<Customer> findByPhoneNumber(String phone) {
        try {
            String sql = "SELECT * FROM customers WHERE phone_number=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, phone);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Customer c = map(rs);
                        rs.close(); ps.close();
                        return Optional.of(c);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    public List<Customer> findByActiveTrue() {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE is_active=true";
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public List<Customer> findByActiveFalse() {
        List<Customer> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM customers WHERE is_active=false";
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public long countByCreatedAtYearAndMonth(int year, int month) {
        try {
            String sql = "SELECT COUNT(*) FROM customers WHERE EXTRACT(YEAR FROM created_at)=? AND EXTRACT(MONTH FROM created_at)=?";
            long c;
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, year);
                ps.setInt(2, month);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    c = rs.getLong(1);
                }
            }
            return c;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Customer save(Customer customer) throws DuplicateCustomerException {
        if (customer.getId() == null) {
            return createCustomer(customer);
        } else {
            try {
                return updateCustomer(customer.getId(), customer);
            } catch (CustomerNotFoundException e) {
                throw new RuntimeException("Không tìm thấy để update", e);
            }
        }
    }

    public void deleteById(Long id) throws CustomerNotFoundException {
        deleteCustomer(id);
    }
}