-- Thêm vai trò mặc định
INSERT INTO roles (name, description) VALUES
('ADMIN', 'Toàn quyền hệ thống'),
('MANAGER','Quản lí chi nhánh'),
('STAFF', 'Nhân viên hạn chế quyền');