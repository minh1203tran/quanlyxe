/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  Minh
 * Created: Aug 8, 2025
 */

CREATE TABLE vehicles (
    -- Thông tin cơ bản
    license_plate VARCHAR(15) NOT NULL COMMENT 'Biển số xe - Primary Key',
    vehicle_type VARCHAR(50) NOT NULL COMMENT 'Loại phương tiện (ô tô, xe máy, xe tải, etc.)',
    brand VARCHAR(100) NOT NULL COMMENT 'Hãng xe',
    model VARCHAR(100) NOT NULL COMMENT 'Model/dòng xe',
    manufacture_year INT NOT NULL COMMENT 'Năm sản xuất',
    
    -- Thông tin chủ sở hữu
    owner_name VARCHAR(200) NOT NULL COMMENT 'Tên chủ sở hữu',
    
    -- Thông tin chi tiết
    color VARCHAR(50) COMMENT 'Màu xe',
    engine_number VARCHAR(50) COMMENT 'Số máy',
    chassis_number VARCHAR(50) COMMENT 'Số khung/số VIN',
    
    -- Thông tin đăng ký
    registration_date DATE COMMENT 'Ngày đăng ký lần đầu',
    inspection_expiry DATE COMMENT 'Ngày hết hạn đăng kiểm',
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo record',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật cuối',
    
    -- Constraints
    PRIMARY KEY (license_plate),
    
    -- Kiểm tra năm sản xuất hợp lệ (từ 1900 đến năm hiện tại + 1)
    CONSTRAINT chk_manufacture_year 
        CHECK (manufacture_year >= 1900 AND manufacture_year <= YEAR(CURDATE()) + 1),
    
    -- Kiểm tra biển số không rỗng
    CONSTRAINT chk_license_plate_not_empty 
        CHECK (LENGTH(TRIM(license_plate)) > 0),
    
    -- Kiểm tra tên chủ sở hữu không rỗng
    CONSTRAINT chk_owner_name_not_empty 
        CHECK (LENGTH(TRIM(owner_name)) > 0)
) ENGINE=InnoDB 
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci 
  COMMENT='Bảng lưu trữ thông tin phương tiện giao thông';

-- =====================================================
-- TẠO CÁC INDEX ĐỂ TỐI ƯU PERFORMANCE
-- =====================================================

-- Index cho việc tìm kiếm theo loại xe
CREATE INDEX idx_vehicle_type ON vehicle(vehicle_type);

-- Index cho việc tìm kiếm theo chủ sở hữu
CREATE INDEX idx_owner_name ON vehicle(owner_name);

-- Index cho việc tìm kiếm theo hãng xe
CREATE INDEX idx_brand ON vehicle(brand);

-- Index cho việc tìm kiếm theo năm sản xuất
CREATE INDEX idx_manufacture_year ON vehicle(manufacture_year);

-- Index cho việc tìm kiếm xe sắp hết hạn đăng kiểm
CREATE INDEX idx_inspection_expiry ON vehicle(inspection_expiry);

-- Composite index cho tìm kiếm theo nhiều tiêu chí
CREATE INDEX idx_type_brand_year ON vehicle(vehicle_type, brand, manufacture_year);

-- Index cho full-text search (nếu cần)
-- CREATE FULLTEXT INDEX idx_fulltext_search ON vehicle(license_plate, brand, model, owner_name);

-- =====================================================
-- TẠO CÁC TRIGGER
-- =====================================================

-- Trigger để tự động cập nhật updated_at
DELIMITER $$

CREATE TRIGGER trg_vehicle_before_update
    BEFORE UPDATE ON vehicle
    FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END$$

-- Trigger để log các thay đổi (tùy chọn)
-- CREATE TRIGGER trg_vehicle_after_insert
--     AFTER INSERT ON vehicle
--     FOR EACH ROW
-- BEGIN
--     INSERT INTO vehicle_audit_log (action, license_plate, created_at)
--     VALUES ('INSERT', NEW.license_plate, NOW());
-- END$$

-- CREATE TRIGGER trg_vehicle_after_update
--     AFTER UPDATE ON vehicle
--     FOR EACH ROW
-- BEGIN
--     INSERT INTO vehicle_audit_log (action, license_plate, old_data, new_data, created_at)
--     VALUES ('UPDATE', NEW.license_plate, 
--             JSON_OBJECT('owner', OLD.owner_name, 'type', OLD.vehicle_type),
--             JSON_OBJECT('owner', NEW.owner_name, 'type', NEW.vehicle_type),
--             NOW());
-- END$$

-- CREATE TRIGGER trg_vehicle_after_delete
--     AFTER DELETE ON vehicle
--     FOR EACH ROW
-- BEGIN
--     INSERT INTO vehicle_audit_log (action, license_plate, old_data, created_at)
--     VALUES ('DELETE', OLD.license_plate, 
--             JSON_OBJECT('owner', OLD.owner_name, 'type', OLD.vehicle_type),
--             NOW());
-- END$$

DELIMITER ;

-- =====================================================
-- TẠO BẢNG AUDIT LOG (TÙY CHỌN)
-- =====================================================

-- CREATE TABLE vehicle_audit_log (
--     id BIGINT AUTO_INCREMENT PRIMARY KEY,
--     action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
--     license_plate VARCHAR(15) NOT NULL,
--     old_data JSON,
--     new_data JSON,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     
--     INDEX idx_license_plate_audit (license_plate),
--     INDEX idx_created_at_audit (created_at)
-- ) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
--   COMMENT='Bảng log các thay đổi trên bảng vehicle';

-- =====================================================
-- INSERT DỮ LIỆU MẪU
-- =====================================================

INSERT INTO vehicle (license_plate, vehicle_type, brand, model, manufacture_year, owner_name, color, engine_number, chassis_number, registration_date, inspection_expiry) VALUES
('30A-12345', 'Ô tô', 'Toyota', 'Camry', 2020, 'Nguyễn Văn A', 'Trắng', 'TYT20001', 'VIN20001', '2020-01-15', '2025-01-15'),
('29B-67890', 'Ô tô', 'Honda', 'Civic', 2019, 'Trần Thị B', 'Đen', 'HND19001', 'VIN19001', '2019-03-20', '2024-03-20'),
('51F-11111', 'Xe máy', 'Honda', 'Wave Alpha', 2021, 'Lê Văn C', 'Đỏ', 'HND21001', 'CHS21001', '2021-05-10', '2026-05-10'),
('59K-22222', 'Xe máy', 'Yamaha', 'Exciter', 2022, 'Phạm Thị D', 'Xanh', 'YMH22001', 'CHS22001', '2022-02-28', '2027-02-28'),
('77S-33333', 'Xe tải', 'Hyundai', 'HD65', 2018, 'Hoàng Văn E', 'Xám', 'HYD18001', 'VIN18001', '2018-07-12', '2023-07-12'),
('43C-44444', 'Ô tô', 'Mazda', 'CX-5', 2023, 'Vũ Thị F', 'Bạc', 'MZD23001', 'VIN23001', '2023-01-05', '2028-01-05'),
('61D-55555', 'Xe máy', 'Suzuki', 'Raider', 2020, 'Đỗ Văn G', 'Đen', 'SUZ20001', 'CHS20001', '2020-09-15', '2025-09-15'),
('14A-66666', 'Ô tô', 'Kia', 'Morning', 2021, 'Bùi Thị H', 'Trắng', 'KIA21001', 'VIN21001', '2021-11-30', '2026-11-30');

-- =====================================================
-- TẠO CÁC VIEW HỮU ÍCH
-- =====================================================

-- View hiển thị xe sắp hết hạn đăng kiểm (trong vòng 30 ngày)
CREATE VIEW v_vehicles_expiring_soon AS
SELECT 
    license_plate,
    vehicle_type,
    brand,
    model,
    owner_name,
    inspection_expiry,
    DATEDIFF(inspection_expiry, CURDATE()) AS days_until_expiry
FROM vehicle 
WHERE inspection_expiry IS NOT NULL 
  AND inspection_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY inspection_expiry;

-- View thống kê theo loại xe
CREATE VIEW v_vehicle_stats_by_type AS
SELECT 
    vehicle_type,
    COUNT(*) as total_count,
    AVG(manufacture_year) as avg_year,
    MIN(manufacture_year) as oldest_year,
    MAX(manufacture_year) as newest_year
FROM vehicle 
GROUP BY vehicle_type
ORDER BY total_count DESC;

-- View thống kê theo hãng xe
CREATE VIEW v_vehicle_stats_by_brand AS
SELECT 
    brand,
    COUNT(*) as total_count,
    COUNT(DISTINCT vehicle_type) as type_variety,
    AVG(manufacture_year) as avg_year
FROM vehicle 
GROUP BY brand
ORDER BY total_count DESC;

-- =====================================================
-- TẠO CÁC STORED PROCEDURE HỮU ÍCH
-- =====================================================

DELIMITER $$

-- Procedure tìm kiếm xe theo nhiều tiêu chí
CREATE PROCEDURE sp_search_vehicles(
    IN p_keyword VARCHAR(255),
    IN p_vehicle_type VARCHAR(50),
    IN p_brand VARCHAR(100),
    IN p_from_year INT,
    IN p_to_year INT
)
BEGIN
    SELECT * FROM vehicle
    WHERE (p_keyword IS NULL OR 
           license_plate LIKE CONCAT('%', p_keyword, '%') OR
           owner_name LIKE CONCAT('%', p_keyword, '%') OR
           model LIKE CONCAT('%', p_keyword, '%'))
      AND (p_vehicle_type IS NULL OR vehicle_type = p_vehicle_type)
      AND (p_brand IS NULL OR brand = p_brand)
      AND (p_from_year IS NULL OR manufacture_year >= p_from_year)
      AND (p_to_year IS NULL OR manufacture_year <= p_to_year)
    ORDER BY license_plate;
END$$

-- Procedure lấy thống kê tổng quan
CREATE PROCEDURE sp_get_vehicle_statistics()
BEGIN
    SELECT 
        COUNT(*) as total_vehicles,
        COUNT(DISTINCT vehicle_type) as total_types,
        COUNT(DISTINCT brand) as total_brands,
        AVG(manufacture_year) as avg_year,
        COUNT(CASE WHEN inspection_expiry < CURDATE() THEN 1 END) as expired_inspection_count
    FROM vehicle;
END$$

DELIMITER ;

-- =====================================================
-- PHÂN QUYỀN (TÙY CHỌN)
-- =====================================================

-- Tạo user cho application
-- CREATE USER 'vehicle_app'@'localhost' IDENTIFIED BY 'secure_password_123';

-- Cấp quyền cần thiết
-- GRANT SELECT, INSERT, UPDATE, DELETE ON vehicle_management.vehicle TO 'vehicle_app'@'localhost';
-- GRANT SELECT ON vehicle_management.v_* TO 'vehicle_app'@'localhost';
-- GRANT EXECUTE ON PROCEDURE vehicle_management.sp_search_vehicles TO 'vehicle_app'@'localhost';
-- GRANT EXECUTE ON PROCEDURE vehicle_management.sp_get_vehicle_statistics TO 'vehicle_app'@'localhost';

-- Áp dụng thay đổi
-- FLUSH PRIVILEGES;

-- =====================================================
-- HIỂN THỊ THÔNG TIN BẢNG ĐÃ TẠO
-- =====================================================

SHOW CREATE TABLE vehicle;
SHOW INDEX FROM vehicle;
SELECT COUNT(*) as 'Total records' FROM vehicle;